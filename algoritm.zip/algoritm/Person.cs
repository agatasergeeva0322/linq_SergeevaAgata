﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace algoritm
{
    class Person
    {
        private string lastname;
        private string name;
        private string otfather;
        private int age;
        private double weidth;

        public Person(string lastname, string name, string otfather, int age, double weidth)
        {
            this.lastname = lastname;
            this.name = name;
            this.otfather = otfather;
            this.age = age;
            this.weidth = weidth;
        }
        public void set_lastname(string n)
        {
            this.lastname = n;
        }
        public string get_lastname()
        {
            return lastname;
        }
        public void set_name(string n)
        {
            this.name = n;
        }
        public string get_name()
        {
            return this.name;
        }
        public void set_otfather(string n)
        {
            this.otfather = n;
        }
        public string get_otfather()
        {
            return this.otfather;
        }
        public void set_age(int n)
        {
            this.age = n;
        }
        public int get_age()
        {
            return this.age;
        }
        public void set_weidth(double n)
        {
            this.weidth = n;
        }
        public double get_weidth()
        {
            return this.weidth;
        }

    }
}
