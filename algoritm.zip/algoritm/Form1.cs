﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace algoritm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Person> people = new List<Person>();
            string file = "file2.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                //Person human = new Person("", "", "", 0, 0);
                string[] lines = File.ReadAllLines(file);
                foreach (string line in lines)
                {
                     Person human = new Person("", "", "", 0, 0);
                    string[] chelovek = line.Split(' ');
                    string lastname = chelovek[0];
                    human.set_lastname(lastname);
                    string name = chelovek[1];
                    human.set_name(name);
                    string otfather = chelovek[2];
                    human.set_otfather(otfather);
                    int age = Convert.ToInt32(chelovek[3]);
                    human.set_age(age);
                    double weidth = Convert.ToDouble(chelovek[4]);
                    human.set_weidth(weidth);
                    people.Add(human);
                }

                var young = from p in people
                            where Convert.ToInt32(p.) < 40
                            select p;
                foreach (var a in young)
                {
                    listBox1.Text = $"{human.get_lastname}";
                }
            }
        }
    }
}
